#!/bin/bash
#
#  install nodejs modules for gothings cloud
#
########
#  
#    
###
echo
echo "------------------------"
echo "  Start GoThings CLOUD"
echo "------------------------"
echo
#
local app message appdir appinjstall retval
app="cloud"
message="install GoThings CLOUD environment"
appdir="/home/yesfi/dockrepo/sysdata/${app}"
retval=0
#
cd "${appdir}"
echo
echo "${app}: ${message}"
echo
echo "Starting docker-compose ..."
docker-compose -f "/home/yesfi/dockrepo/sysdata/${app}/gothings${app}install.yml" up -d
retval=$?
echo
echo "${app}: ${message}"
echo "  DONE -----------------------------"
echo
return ${retval}