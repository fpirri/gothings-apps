#!/bin/bash
#
#  init nodejs modules for gothings cloud
#
########
#  
#    
###
echo
echo "------------------------"
echo "  INIT GoThings CLOUD"
echo "------------------------"
echo
#
local app message appdir appinit retval
app="cloud"
message="init GoThings CLOUD environment"
appdir="/home/yesfi/dockrepo/sysdata/${app}"
retval=0
#
cd "${appdir}"
echo
echo "${app}: ${message}"
echo 
echo "Install gothings docker networks"
echo "Please note that the following will show 'already exists' errors"
echo "if the network was already installed"
echo 
echo "- gothingsnet"
docker network create -d bridge --subnet 172.29.196.0/24 --gateway 172.29.196.1 gothingsnet  
echo "- servicenet"
docker network create -d bridge --subnet 172.29.195.0/24 --gateway 172.29.195.1 servicenet
echo
#
#retval=$?
#
echo
echo "${app}: ${message}"
echo "  DONE -----------------------------"
echo
return ${retval}