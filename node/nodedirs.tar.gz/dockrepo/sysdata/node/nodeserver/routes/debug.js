
module.exports = async function (req, res, next) {


//  External homepage with object - through the nginx proxy
#app.get('/user/:subpath', (req, res, next) => {
  try {
    res.type('.html')
    var i;
    res.write('Hello, I am syslog, listening from the internet via the nginx proxy ! <br>');
    res.write('Debug list:<br>');
    for (i = 0; i < list_maxlen; i++) {
      const log_value = await getelement(gtbase_loglist, i);
      res.write('<br>'+log_value);
    } 
    res.write('<br>You called user with subpath: '+req.params.subpath);
    res.write('<br>Query parameters are:<br>'+JSON.stringify(req.query));
    res.write('<br>My counter value is: '+mycount);
    res.end();
    next();
  } catch (error) {
    next(error);    
  }
});

};