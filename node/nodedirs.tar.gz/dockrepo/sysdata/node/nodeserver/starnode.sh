#!/bin/bash
#
#  startup file per contenitore node service
#
#############
#
echo
echo "NODE Services: lancio del server http"
node index.js
echo "ho eseguito:  node index.js"
echo "-----------------------------"
echo 
