#!/bin/bash
#
#  startup file per contenitore Node Service
#
#############
#
echo
echo "NODE: lancio del server index-service.js"
node index-service.js
echo "ho eseguito:  node index-service.js"
echo "-----------------------------"
echo 