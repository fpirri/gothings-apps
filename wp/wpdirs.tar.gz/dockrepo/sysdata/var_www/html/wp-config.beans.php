<?php
/**
 * 
 * Adjusted by FPGothings on 2020-02-05
 * 
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'gtlite');

/** MySQL database username */
define( 'DB_USER', 'Pluto1945');

/** MySQL database password */
define( 'DB_PASSWORD', 'Himage_2019_IoT');

/** MySQL hostname */
define( 'DB_HOST', '10.133.94.60');

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'e85ba6e9a0326cce210c27b83c451b663a500a06');
define( 'SECURE_AUTH_KEY',  '20640141895ad4114e22dd53a9ce4f943e85a1d5');
define( 'LOGGED_IN_KEY',    'c8ee43b50d8712c22ae7572fd29e42ae134ff88e');
define( 'NONCE_KEY',        'fdf0984da53257aa7d34076bc07201b635ba5900');
define( 'AUTH_SALT',        '52cb57b2b92e57c5d971de164ca8cd09e5dd8f88');
define( 'SECURE_AUTH_SALT', '6aec43220fd0a2ac480bd90810a9e0068f074333');
define( 'LOGGED_IN_SALT',   'eba9ffcbf1822af5c998af3f665b0ef3576f6eb3');
define( 'NONCE_SALT',       '3c94543e00bc1583faf43a8de99f0e1edffe80ad');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'GoTh01_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

// If we're behind a proxy server and using HTTPS, we need to alert Wordpress of that fact
// see also http://codex.wordpress.org/Administration_Over_SSL#Using_a_Reverse_Proxy
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
	$_SERVER['HTTPS'] = 'on';
}

/* Multisite settings */
define( 'WP_ALLOW_MULTISITE', true );

define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', true);
define('DOMAIN_CURRENT_SITE', 'www.gothings.org');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

/* define('SUNRISE', 'on');  <-- a cher serve? */

define('NOBLOGREDIRECT', 'http://gothings.org');

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
