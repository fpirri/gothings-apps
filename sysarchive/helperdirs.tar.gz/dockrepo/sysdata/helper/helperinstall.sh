#!/bin/bash
#                                                                                         2020-03-01
                                                                                     VERSION=0.00.01
#
#  install nodejs modules for gothings helper
#
########
#  
APP="helper"
DISPAYNAME=${APP^^}
#    
###
echo
echo "--------------------------"  v$VERSION}
echo "  Start GoThings ${DISPLAYNAME}"
echo "--------------------------"
echo
#
install() {
  local app message appdir appinstall retval
  message="install GoThings ${APP} environment"
  appdir="/home/yesfi/dockrepo/sysdata/${APP}"
  retval=0
  #
  cd "${appdir}"
  echo
  echo "${APP}: ${message}"
  echo
  echo "Starting docker-compose ..."
  docker-compose -f "/home/yesfi/dockrepo/sysdata/${APP}/gothings${APP}install.yml" up -d
  retval=$?
  message="Install process returns: ${retval}"
  # segnalazione di errore:                                         DA FARE
  echo
  echo "${DISPLAYNAME}: ${message}"
}
install
echo
echo "  DONE -----------------------------"
echo
return ${retval}