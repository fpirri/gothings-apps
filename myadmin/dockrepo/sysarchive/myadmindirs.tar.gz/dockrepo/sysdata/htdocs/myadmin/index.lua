local name = ngx.var.arg_name or "Anonymous"
ngx.say("Hello, ", name, "!")
ngx.say("--------------------------------------------------------------")
ngx.say("sito test - lua file location: /var/www/test/index.lua")
